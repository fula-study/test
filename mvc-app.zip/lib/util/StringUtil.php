<?php
class StringUtil {
    public static function toUpperCase($str) {
        return mb_strtoupper($str, 'UTF-8');
    }
}
