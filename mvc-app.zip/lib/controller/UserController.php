<?php
require_once BASE_PATH . '/lib/model/UserModel.php';
require_once BASE_PATH . '/lib/util/StringUtil.php';

class UserController {
    public function handleRequest() {
        $action = $_GET['action'] ?? 'menu';

        switch ($action) {
            case 'login':
                require BASE_PATH . '/web/view/login.php';
                break;
            case 'menu':
                require BASE_PATH . '/web/view/menu.php';
                break;
            case 'register':
                require BASE_PATH . '/web/view/user_register.php';
                break;
            case 'search':
                require BASE_PATH . '/web/view/user_search.php';
                break;
            case 'edit':
                require BASE_PATH . '/web/view/user_edit.php';
                break;
            default:
                echo "不正なアクションです";
        }
    }
}
