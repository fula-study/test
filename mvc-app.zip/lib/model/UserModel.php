<?php
class UserModel {
    // ダミーのユーザー検索
    public function findUserById($id) {
        return ['id' => $id, 'name' => 'サンプル', 'email' => 'sample@example.com'];
    }
}
