<h1>ユーザ情報検索</h1>
<form method="get" action="?action=edit">
  <label>ユーザID: <input type="text" name="id"></label>
  <button type="submit">検索</button>
</form>
