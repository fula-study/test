<h1>ユーザ情報更新</h1>
<form method="post" action="?action=edit">
  <input type="hidden" name="id" value="1">
  <label>名前: <input type="text" name="name" value="サンプル"></label><br>
  <label>メール: <input type="email" name="email" value="sample@example.com"></label><br>
  <button type="submit">更新</button>
</form>
