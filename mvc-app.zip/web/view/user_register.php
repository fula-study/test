<h1>ユーザ情報登録</h1>
<form method="post" action="?action=register">
  <label>名前: <input type="text" name="name"></label><br>
  <label>メール: <input type="email" name="email"></label><br>
  <button type="submit">登録</button>
</form>
