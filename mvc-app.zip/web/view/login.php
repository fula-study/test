<h1>ログイン画面</h1>
<form method="post" action="?action=menu">
  <label>ユーザー名: <input type="text" name="username"></label><br>
  <label>パスワード: <input type="password" name="password"></label><br>
  <button type="submit">ログイン</button>
</form>
