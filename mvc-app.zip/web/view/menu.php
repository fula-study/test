<h1>メニュー画面</h1>
<ul>
  <li><a href="?action=register">ユーザ情報登録</a></li>
  <li><a href="?action=search">ユーザ情報検索</a></li>
</ul>
