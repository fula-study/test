<?php
define('BASE_PATH', realpath(__DIR__ . '/../'));
require_once BASE_PATH . '/lib/controller/UserController.php';

$controller = new UserController();
$controller->handleRequest();
