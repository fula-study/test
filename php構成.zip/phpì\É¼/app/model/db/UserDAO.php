<?php
require_once 'config/database.php';
require_once 'model/db/entity/User.php';

class UserDAO {
    private $pdo;

    public function __construct() {
        $this->pdo = Database::getConnection();
    }

    public function getAllUsers() {
        $stmt = $this->pdo->query("SELECT * FROM users");
        return $this->mapUsers($stmt);
    }

    public function getUsersWhere($condition) {
        $stmt = $this->pdo->query("SELECT * FROM users WHERE $condition");
        return $this->mapUsers($stmt);
    }

    private function mapUsers($stmt) {
        $users = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $user = new User();
            $user->id = $row['id'];
            $user->name = $row['name'];
            $user->email = $row['email'];
            $user->active = $row['active'];
            $users[] = $user;
        }

        return $users;
    }
}