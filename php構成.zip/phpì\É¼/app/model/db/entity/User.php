<?php

class User {
    public $id;
    public $name;
    public $email;
    public $active;
}