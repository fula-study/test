<?php
require_once 'model/UserModel.php';

class UserController {
    public function listUsers() {
        $model = new UserModel();
        $users = $model->getActiveUsers(); // Model = ���W�b�N�S��

        require 'view/user_list.php';
    }
}